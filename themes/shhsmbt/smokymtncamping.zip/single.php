<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package smokymtncamping
 */

get_header(); ?>

	<main id="primary" class="entry-content site-main">
	<?php
	while ( have_posts() ) : the_post();
        ?>
        <a href="/news" class="back-to-news">
            <svg xmlns="http://www.w3.org/2000/svg" width="17.525" height="17.525"><path data-name="Icon awesome-arrow-circle-left" d="M8.762 17.525a8.763 8.763 0 118.763-8.763 8.761 8.761 0 01-8.763 8.763zm1.021-5.074L7.116 9.893h6.452a.846.846 0 00.848-.848V8.48a.846.846 0 00-.848-.848H7.116l2.668-2.558a.849.849 0 00.014-1.212l-.389-.385a.845.845 0 00-1.2 0L3.522 8.162a.845.845 0 000 1.2l4.689 4.689a.845.845 0 001.2 0l.389-.385a.849.849 0 00-.017-1.215z" fill="#5a5c62"/></svg>
            BACK TO NEWS AND MORE
        </a>

        <?php
		get_template_part( 'template-parts/content', get_post_type() );

	endwhile; // End of the loop.
	?>

	</main><!-- #primary -->

<?php
get_footer();
