<?php
?>
<p> Colorful Box Grid </p>