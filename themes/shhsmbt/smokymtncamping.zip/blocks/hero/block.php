<?php

?>
<div class="hero-block" style="background-image: url(<?php block_field('background') ?>)">
    <div class="hero-content">
        <?php block_field('block');  ?>
    </div>
</div>