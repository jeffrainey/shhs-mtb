<?php
?>
<p> Contact Info Block </p>