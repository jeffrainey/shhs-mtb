<?php

?>
<div>
    <?php block_field('block');  ?>
</div>