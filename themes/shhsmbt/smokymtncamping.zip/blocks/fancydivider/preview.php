<?php
?>
<div class="fancy-divider-wrapper">
<div class="fancy-divider-line"></div>
<img class="logo-divider" src="/wp-content/themes/smokymtncamping/dist/images/logo-divider.png">
</div>