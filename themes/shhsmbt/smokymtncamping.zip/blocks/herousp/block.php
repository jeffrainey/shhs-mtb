<?php

?>
<div class="hero-box">
    <div class="hero-box-content">
        <?php block_field('block');  ?>
    </div>
</div>