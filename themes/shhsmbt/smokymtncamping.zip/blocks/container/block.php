<?php

?>
<div class="container-block" style="background-image: url(<?php block_field('background') ?>)">
    <div class="container-content">
        <?php block_field('block');  ?>
    </div>
</div>