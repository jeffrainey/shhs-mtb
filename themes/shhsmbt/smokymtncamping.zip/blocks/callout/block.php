<?php

?>
<!--<img src="--><?php //block_field('background');  ?><!--">-->
<div style="background-image: url(<?php block_field('background') ?>)">
    <h1><?php block_field('header');  ?></h1>

    <p>
        <?php block_field('body');  ?>
    </p>
</div>