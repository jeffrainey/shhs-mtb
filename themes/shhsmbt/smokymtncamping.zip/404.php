<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package smokymtncamping
 */

get_header(); ?>

    <main id="primary" class="site-main">
        <div class="entry-content">
            <article>

            </article><!-- .error-404 -->
        </div>
	</main><!-- #primary -->
<?php
get_footer();
