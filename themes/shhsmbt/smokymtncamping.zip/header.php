<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package smokymtncamping
 */

//$logo_id = carbon_get_theme_option('template_logo');
//$logo = wp_get_attachment_url($logo_id);
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <!--<link rel="shortcut icon" href="/wp-content/themes/smokymtncamping/dist/assets/images/favicon.ico">-->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&family=Wendy+One&display=swap" rel="stylesheet">
    <?php wp_head();
   // echo carbon_get_theme_option( 'header_scripts' ); ?>
</head>

<body <?php body_class(); ?>>
    <?
        if ( get_theme_mod('facebook') && get_theme_mod('facebook-footer')){
            ?>
            <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v14.0" nonce="zkHlEhFs"></script>
            <?
        }
    ?>
    <div id="page" class="site">
        <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'sero_core' ); ?></a>
            <div class="top-header">
                <div class="contact-info">
                <?php
                if( get_theme_mod('address_street') ) : ?>
                    <p><?php echo get_theme_mod('address_street') . ', ' . get_theme_mod('address_city') . ', ' . get_theme_mod('address_state') .' ' . get_theme_mod('address_zip') ?></p>
                    <?php endif;
                    if( get_theme_mod('hours_weekday') ) : ?>
                        <p><?php echo get_theme_mod('hours_weekday') . ' | ' . get_theme_mod('hours_weekend') ?></p>
                    <?php endif;
                if( get_theme_mod('phonenumber')) : ?>
                    <a href="tel:<?php echo get_theme_mod('phonenumber') ?>"><?php echo get_theme_mod('phonenumber') ?></a> <span class='white-text'>|</span> 
                <?php endif;
                
                if( get_theme_mod('email')) : ?>
                    <a href="mailto:<?php echo get_theme_mod('email') ?>"><?php echo get_theme_mod('email') ?></a>
                <?php endif;?>
                </div>
                <?php
                if( get_theme_mod('ctabutton_buttonlink')) : ?>
                    <div class="cta-button inner-shadow"><a href="<?php echo get_theme_mod('ctabutton_buttonlink') ?>"><?php echo get_theme_mod('ctabutton_buttontext') ?></a></div>
                <?php endif;?>

            </div>
            <header class="site-header">
                <div class="header-main-nav">
                    <section class="header-nav">
                        <!-- #site-navigation -->
                        <div class="header-logo">
                            <a href="/">
                                <img src="/wp-content/themes/smokymtncamping/dist/images/logo_header.png" alt="Smoky Mountain Premium Camping" />
                            </a>
                        </div>
                        <div>
                            <nav id="site-navigation" class="main-navigation">
                                <?php
                                wp_nav_menu( array(
                                    'theme_location' => 'menu-1',
                                    'menu_id'        => 'primary-menu',
                                ) );
                                ?>
                            </nav><!-- #site-navigation -->
                        </div>
                    </section>

                    <div id="navbtn">
                        <!--                        <div id="nav-box"></div>-->
                        <div class="nav-lines"></div>
                    </div>

                    <nav id="site-navigation" class="main-nav menu-mobile">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'menu-2',
                            'menu_id'        => 'mobile-menu',
                            'menu_class'     => 'mobile-menu'
                        ));
                        ?>
                        <div class="mobile-contact-info">
                            <div class="mobile-contact">
                                <?php
                                if( get_theme_mod('phonenumber')) : ?>
                                    <p><?php echo get_theme_mod('phonenumber') ?></p>
                                <?php endif; ?>

                                <?php if( get_theme_mod('email')) : ?>
                                    <a class="email" href="mailto:<?php echo get_theme_mod('email') ?>">
                                        email us
                                    </a>
                                <?php endif; ?>

                                <?php if( get_theme_mod('hours_weekday') ) : ?>
                                    <p><?php echo get_theme_mod('hours_weekday') . ' | ' . get_theme_mod('hours_weekend') ?></p>
                                <?php endif;?>
                            </div>

                            <div class="socialmedia">
                                <?php
                                if( get_theme_mod('facebook') ){ ?>
                                    <a href="<?php echo get_theme_mod('facebook'); ?>" target="_blank">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" width="18" height="18"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"/></svg>
                                    </a>
                                <?php }

                                if( get_theme_mod('twitter') ){ ?>
                                    <a href="<?php echo get_theme_mod('twitter'); ?>" target="_blank">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="18" height="18"><!--! Font Awesome Pro 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"/></svg>
                                    </a>
                                <?php }

                                if( get_theme_mod('linkedin') ){ ?>
                                    <a href="<?php echo get_theme_mod('linkedin'); ?>" target="_blank">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="20" height="20"><!-- Font Awesome Pro 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) --><path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"/></svg>
                                    </a>
                                <?php }
                                if( get_theme_mod('google') ){ ?>
                                    <a href="<?php echo get_theme_mod('google'); ?>" target="_blank">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512" width="18" height="18"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"/></svg>
                                    </a>
                                <?php }
                                if( get_theme_mod('youtube') ){ ?>
                                    <a href="<?php echo get_theme_mod('youtube'); ?>" target="_blank">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" width="20" height="20"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"/></svg>
                                    </a>
                                <?php }
                                ?>
                            </div>
                        </div>
                    </nav><!-- #site-navigation -->
                </div>
            </header>