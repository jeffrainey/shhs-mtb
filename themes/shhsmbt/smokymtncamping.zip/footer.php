<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package smokymtncamping
 */

?>
        <footer id="footer" class="mt-20">
            <div class="footer-wrap">
                <div class="col col-1">
                    <h2>Our Facebook</h2>
                    <? //fb section appearance depends on customizer selection
                        if ( get_theme_mod('facebook') && ( get_theme_mod('facebook-footer') == 1 ) ){
                            ?>
                            <div class="fb-page" data-href="<? echo get_theme_mod('facebook') ?>" data-lazy="true" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
                            <?
                        }
                    ?>
                </div>
                <div class="col col-2">
                    <h2>About Us</h2>
                    <? //fb section appearance depends on customizer selection
                        if ( get_theme_mod('facebook') && ( get_theme_mod('facebook-footer') == 2 ) ){
                            ?>
                            <div class="fb-page" data-href="<? echo get_theme_mod('facebook') ?>" data-lazy="true" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
                            <?
                        }
                    ?>
                    <?php if( get_theme_mod('footer-about')) : ?>
                        <p><?php echo get_theme_mod('footer-about') ?></p>
                    <?php endif; ?>
                </div>
                <div class="col col-3">
                    <h2>Contact Us</h2>
                    <? //fb section appearance depends on customizer selection
                        if ( get_theme_mod('facebook') && ( get_theme_mod('facebook-footer') == 3 ) ){
                            ?>
                            <div class="fb-page" data-href="<? echo get_theme_mod('facebook') ?>" data-lazy="true" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
                            <?
                        }
                    ?>
                    <?php if( get_theme_mod('address_street') ) : ?>
                        <p><?php echo get_theme_mod('address_street') . ', ' . get_theme_mod('address_city') . ', ' . get_theme_mod('address_state') .' ' . get_theme_mod('address_zip') ?></p>
                    <?php endif;

                    if( get_theme_mod('phonenumber')) : ?>
                        <div><p>Phone:</p>
                        <a href="tel:<? echo get_theme_mod('phonenumber'); ?>"><?php echo get_theme_mod('phonenumber') ?></a></div>
                    <?php endif;

                    if( get_theme_mod('hours_weekday') ) : ?>
                        <div><p>Hours:</p>
                        <p><?php echo get_theme_mod('hours_weekday') . ' | ' . get_theme_mod('hours_weekend') ?></p></div>
                    <?php endif;

                    if( get_theme_mod('email')) : ?>
                        <div><p>Email:</p>
                        <a href="mailto:<? echo get_theme_mod('email'); ?>"><?php echo get_theme_mod('email') ?></a></div>
                    <?php endif;?>

                </div>
            </div>
            <div class="pz-fanfare">
                <img src="<? echo get_stylesheet_directory_uri(); ?>/dist/images/PZ_Logo.png">
            </div>
            <div class="copyright-bar white-text center">
                    &copy; <? echo date("Y"); ?> Smoky Mountain Premium Camping
                </div>
        </footer><!-- #footer -->
    </div><!-- #page -->
    <?php wp_footer(); ?>
</body>
</html>

