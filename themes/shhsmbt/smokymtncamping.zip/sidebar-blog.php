<div id="sidebar-blog" class="sidebar">
    <?php dynamic_sidebar( 'sidebar-blog' ); ?>
</div>